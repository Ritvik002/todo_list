const express = require("express");
const app = express();
const port = 3000;
const mongoose = require('mongoose')

mongoose.connect('mongodb://127.0.0.1:27017/',{useNewUrlParser: True, useUnifiedTopology: True})
.then(()=>console.log("The db is connected"))
.catch((err)=>console.log(err))

const { engine } = require('express-handlebars');

app.engine('handlebars', engine());
app.set('view engine', 'handlebars');
app.set('views', './views');

app.use(express.static(__dirname + '/public'));


app.get('/', (req, res) => {
    res.render('login');
});


app.get('/home', (req, res) => {
    res.render('home');
});


app.get('/signup', (req, res) => {
    res.render('signup');
});

app.listen(port, () => {
    console.log(`Example app listening on port ${port}`)
})