const {Schema, model} = require('mongoose');

const toDoSchema = new Schema({
    taskName:{
        type:String,
        required:True
    },
    taskDesc:{
        type:String,
        required:True
    }
})

toDoModel = model('todo', toDoSchema)

module.exports = toDoModel